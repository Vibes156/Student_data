from flask import Flask, render_template, request, redirect, url_for
import pymysql
db_connection = None
tb_cursor = None

#create object of Flask class
app = Flask(__name__)

# function to connect to databse
def connectionToDb():
    global db_connection, tb_cursor
    db_connection=pymysql.connect(host="localhost",user="root",
    passwd="",database="my_to_do_list",port=3306)
    if(db_connection):
        print("Done!!!")
    else:
        print("Not done")
    tb_cursor=db_connection.cursor()

# function to dicconnect from databse
def disconnectDb():
    db_connection.close()
    tb_cursor.close()

# function to get data from databse
def getAllTaskData():
    connectionToDb()
    selectQuery = "SELECT * FROM daily_list;"
    tb_cursor.execute(selectQuery)
    allData = tb_cursor.fetchall()
    disconnectDb()
    return allData

#function to insert data into the table
def insertIntoTable(task_name,status):
    connectionToDb()
    inserQuery = "INSERT INTO daliy_list(TASK_NAME,STATUS) VALUES(%s, %s);"
    tb_cursor.execute(inserQuery,(task_name,status))
    db_connection.commit()
    disconnectDb()
    return True

# function to get data of one student from databse
def getTaskID(daily_list_id):
    connectionToDb()
    selectQuery = "SELECT * FROM daily_list WHERE ID=%s;"
    tb_cursor.execute(selectQuery,(daily_list_id,))
    oneData = tb_cursor.fetchone()
    disconnectDb()
    return oneData

#function to update data into the table
def updateTaskIntoTable(task_name,status,id):
    connectionToDb()
    updateQuery = "UPDATE daily_list SET TASK_NAME=%s,STATUS=%s WHERE ID=%s;"
    tb_cursor.execute(updateQuery,(task_name,status,id))
    db_connection.commit()
    disconnectDb()
    return True

#function to update data into the table
def deleteTaskFromTable(id):
    connectionToDb()
    deleteQuery = "DELETE FROM daily_list WHERE ID=%s;"
    tb_cursor.execute(deleteQuery,(id,))
    db_connection.commit()
    disconnectDb()
    return True



#a method that envoked at server execution
@app.route("/")
@app.route("/index/")
def index():
    #return "Hello flask"
    #return render_template("index.html")
    allData = getAllTaskData()
    return render_template("index.html",data = allData)

@app.route("/add/",methods=["GET","POST"])
def addTask():
    if request.method == "POST":
        data = request.form
        isiInserted = insertIntoTable(data['txtTask_Name'],data['txtStatus'],)
        if(isiInserted):
            message = "Insertion sucess"
        else:
            message = "Insertion Error"
        return render_template("add.html",message = message)
    return render_template("add.html")

@app.route("/update/",methods=["GET","POST"])
def updateTask():
    id = request.args.get("ID",type=int,default=1)
    idData = getTaskID(id)
    if request.method == "POST":
        data = request.form
        print(data)
        isUpdated = updateTaskIntoTable(data['txtTask_Name'],data['txtStatus'],id)
        if(isUpdated):
            message = "Updattion sucess"
        else:
            message = "Updattion Error"
        return render_template("update.html",message = message)
    return render_template("update.html",data=idData)

@app.route("/delete/")
def deleteTask():
    id = request.args.get("ID",type=int,default=1)
    deleteTaskFromTable(id)
    return redirect(url_for("index"))


#to execute the code
if __name__=='__main__':
    app.run(debug=True)